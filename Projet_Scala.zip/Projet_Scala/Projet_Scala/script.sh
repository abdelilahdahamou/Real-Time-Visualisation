#!/bin/bash
streaming_dir="/home/dba/Projet_Scala"
while [ 1 ]
do
	mylogfile="mylogfile_$(date +%s).csv"
	./log-generator.py >> $mylogfile
	mv $mylogfile ${streaming_dir}/
	echo "$mylogfile is generated"
	sleep 5
done	
